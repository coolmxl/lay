{
  "status": 200,
  "msg": "",
  "count": "100",
  "data": [{
      "id": "001",
      "name": "店长-1",
      "info": "Antony",
      "headImg": "https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJtZKicrNcVeq5pKLyKiboKvymyF3oknGqTuzCNPvMXgtAPAfTLPxMwog4ucJ6ibNKouctpsdSPEUxvg/132",
      "contact": 12345678901,
      "loginName": "Antony",
      "applyId": "402881eb6e7c4b4e016e7c4b84260000",
      "appletUserId": "402881eb6e7c4b4e016e7c4b84260000",
      "nickName": "Antony",
      "createDate": "2019-11-18 10:15:54"
    },
    {
      "id": "001",
      "name": "店长-1",
      "info": "Antony",
      "headImg": "https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJtZKicrNcVeq5pKLyKiboKvymyF3oknGqTuzCNPvMXgtAPAfTLPxMwog4ucJ6ibNKouctpsdSPEUxvg/132",
      "contact": 12345678901,
      "loginName": "Antony",
      "applyId": "402881eb6e7c4b4e016e7c4b84260000",
      "appletUserId": "402881eb6e7c4b4e016e7c4b84260000",
      "nickName": "Antony",
      "createDate": "2019-11-18 10:15:54"
    },
    {
      "id": "001",
      "name": "店长-1",
      "info": "Antony",
      "headImg": "https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJtZKicrNcVeq5pKLyKiboKvymyF3oknGqTuzCNPvMXgtAPAfTLPxMwog4ucJ6ibNKouctpsdSPEUxvg/132",
      "contact": 12345678901,
      "loginName": "Antony",
      "applyId": "402881eb6e7c4b4e016e7c4b84260000",
      "appletUserId": "402881eb6e7c4b4e016e7c4b84260000",
      "nickName": "Antony",
      "createDate": "2019-11-18 10:15:54"
    },
    {
      "id": "001",
      "name": "店长-1",
      "info": "Antony",
      "headImg": "https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJtZKicrNcVeq5pKLyKiboKvymyF3oknGqTuzCNPvMXgtAPAfTLPxMwog4ucJ6ibNKouctpsdSPEUxvg/132",
      "contact": 12345678901,
      "loginName": "Antony",
      "applyId": "402881eb6e7c4b4e016e7c4b84260000",
      "appletUserId": "402881eb6e7c4b4e016e7c4b84260000",
      "nickName": "Antony",
      "createDate": "2019-11-18 10:15:54"
    }
    
  ]
}