{
    "status": 200,
    "msg": "",
    "count": "100",
    "data": [{
        "id": "402881eb6e7c4b4e016e7c4b84260000",
        "nickName": "Antony",
        "avatarUrl": "https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJtZKicrNcVeq5pKLyKiboKvymyF3oknGqTuzCNPvMXgtAPAfTLPxMwogYWwgsMzFfPpyj6oorFHRhA/132",
        "createDate": "2019-11-18 10:15:54.0",
        "realName": null,
        "phoneNumber": "18483679330",
        "gender": "MALE",
        "userType": "SHOP_USER",
        "totalOrderCount": null,
        "totalOrderAmount": null
    }]
}