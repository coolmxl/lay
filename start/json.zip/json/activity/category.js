{
    "status": 200,
    "msg": "",
    "count": "100",
    "data": [{
        "id": "1001",
        "name": "沙龙",
        "weight": 1,
        "createDate": "2019-11-18 10:15:54"
    }, {
        "id": "1001",
        "name": "活动",
        "weight": 2,
        "createDate": "2019-11-18 10:15:54"
    }, {
        "id": "1001",
        "name": "演唱会",
        "weight": 3,
        "createDate": "2019-11-18 10:15:54"
    }, {
        "id": "1001",
        "name": "分享会",
        "weight": 4,
        "createDate": "2019-11-18 10:15:54"
    }]
}