{
    "status": 200,
    "msg": "",
    "count": "100",
    "data": [{
        "id": "1001",
        "headImg": "https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJtZKicrNcVeq5pKLyKiboKvymyF3oknGqTuzCNPvMXgtAPAfTLPxMwogYWwgsMzFfPpyj6oorFHRhA/132",
        "title": "Antony",
        "blnHot": true,
        "price": "70.00",
        "capacity": "100",
        "viewCount":"2000",
        "city":{
            "id":"",
            "name":"眉山"
        },
        "shop":{
            "id":"",
            "name":"商店名称"
        },
        "category":{
            "id":"",
            "name":"沙龙"
        },
        "createDate": "2019-11-18 10:15:54"
    },
    {
        "id": "1001",
        "headImg": "https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJtZKicrNcVeq5pKLyKiboKvymyF3oknGqTuzCNPvMXgtAPAfTLPxMwogYWwgsMzFfPpyj6oorFHRhA/132",
        "title": "Antony",
        "blnHot": true,
        "price": "70.00",
        "capacity": "100",
        "viewCount":"2000",
        "city":{
            "id":"",
            "name":"眉山"
        },
        "shop":{
            "id":"",
            "name":"商店名称"
        },
        "category":{
            "id":"",
            "name":"沙龙"
        },
        "createDate": "2019-11-18 10:15:54"
    },
    {
        "id": "1001",
        "headImg": "https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJtZKicrNcVeq5pKLyKiboKvymyF3oknGqTuzCNPvMXgtAPAfTLPxMwogYWwgsMzFfPpyj6oorFHRhA/132",
        "title": "Antony",
        "blnHot": true,
        "price": "70.00",
        "capacity": "100",
        "viewCount":"2000",
        "city":{
            "id":"",
            "name":"眉山"
        },
        "shop":{
            "id":"",
            "name":"商店名称"
        },
        "category":{
            "id":"",
            "name":"沙龙"
        },
        "createDate": "2019-11-18 10:15:54"
    }]
}